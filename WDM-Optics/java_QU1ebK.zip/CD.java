import java.util.*;
import java.util.Calendar;
import java.util.Random;
import java.util.Calendar;

public class CD{
  ArrayList<String> myArr1 = new ArrayList<String>();
  ArrayList<String> myArr2 = new ArrayList<String>();
  String str;
   
  
  public void inDuration(Double num){
    str= String.valueOf(num);
    myArr.add(str);
  }
  
  public void outDuration(){
    
    
    System.out.println("is : "+ myArr);
  }
  
   public void inPacket(Double num)
  {
     startTimerOut();
    myArr2.add();
  }
  
  
  
   public void  outPacketLine(){
     
     startTimerOut()
     
  }
  
  
}





