import java.util.*;
import java.util.Calendar;
import java.util.Random;
import java.util.Calendar;

public class Main {

	public static void main(String[] args) {
		Station station =new Station();
		
		
		
//		station.station("PC1",1,'a');
//		station.station("PC2",2,'a');
//		station.station("PC3",3,'b');
//		station.station("PC4",4,'b');
//		station.station("PC5",5,'c');
//		station.station("PC6",6,'c');
//		station.station("PC7",7,'d');
//		station.station("PC8",8,'d');
		
		for(int j=0;j<5;j++){
		station.PC();              
        }
       station.AL_index();
		//station.iterateTable();
		//System.out.println("number is:"+ );
		}
	}



